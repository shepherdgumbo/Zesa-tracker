#!/usr/bin/env node
/*
  One-time production hardening for the existing server.js.
  Run from the repository root:
      node scripts_harden.js
  The script creates server.js.pre-production-backup before editing.
*/
const fs = require("node:fs");
const path = require("node:path");

const root = process.cwd();
const file = path.join(root, "server.js");
let source = fs.readFileSync(file, "utf8");

if (source.includes("ZESATRACKER_PRODUCTION_HARDENING")) {
  console.log("Production hardening is already present.");
  process.exit(0);
}

fs.copyFileSync(file, `${file}.pre-production-backup`);

source = source.replace(
  'const express = require("express");',
  'const express = require("express");\nconst path = require("path");'
);

source = source.replace(
  'const PORT = process.env.PORT || 10000;',
  'const PORT = process.env.PORT || 10000;\n\n// ZESATRACKER_PRODUCTION_HARDENING\napp.set("trust proxy", 1);'
);

source = source.replace(
  'app.use(cors());',
  `app.use(cors({
  origin: (origin, callback) => {
    const allowed = (process.env.ALLOWED_ORIGINS || "").split(",").map(v => v.trim()).filter(Boolean);
    if (!origin || allowed.length === 0 || allowed.includes(origin)) return callback(null, true);
    return callback(new Error("Origin not allowed"));
  },
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type"]
}));`
);

source = source.replace(
  'app.use(express.json({ limit: "1mb" }));',
  'app.use(express.json({ limit: "64kb" }));'
);

const marker = '// ZESATRACKER_PWA_ASSETS';
const pwa = `
${marker}
const PUBLIC_DIR = path.join(__dirname, "public");

app.get("/manifest.webmanifest", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "manifest.webmanifest"), {
    headers: { "Cache-Control": "public, max-age=86400" }
  });
});

app.get("/sw.js", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "sw.js"), {
    headers: {
      "Content-Type": "application/javascript; charset=utf-8",
      "Cache-Control": "no-cache"
    }
  });
});

app.get("/icon.svg", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "icon.svg"), {
    headers: { "Cache-Control": "public, max-age=604800" }
  });
});

// Inject install metadata into the existing server-rendered HTML without
// replacing the application's current UI.
app.use((req, res, next) => {
  const originalSend = res.send.bind(res);
  res.send = (body) => {
    if (typeof body === "string" && /<html[\s>]/i.test(body)) {
      let html = body;
      if (!/manifest\.webmanifest/i.test(html)) {
        html = html.replace(/<\/head>/i,
          '<link rel="manifest" href="/manifest.webmanifest"><meta name="theme-color" content="#0b5ed7"></head>');
      }
      if (!/serviceWorker/i.test(html)) {
        html = html.replace(/<\/body>/i,
          '<script>if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});</script></body>');
      }
      return originalSend(html);
    }
    return originalSend(body);
  };
  next();
});
`;

const listenMarker = /\napp\.listen\(PORT,[\s\S]*?\n\}\);\s*$/m;
if (source.includes("app.listen(PORT")) {
  const match = source.match(listenMarker);
  if (match) {
    source = source.slice(0, match.index) + pwa + "\n" + source.slice(match.index);
  } else {
    const idx = source.lastIndexOf("app.listen(PORT");
    source = source.slice(0, idx) + pwa + "\n" + source.slice(idx);
  }
} else {
  source += pwa;
}

fs.writeFileSync(file, source);
console.log("Production hardening applied. Backup:", `${file}.pre-production-backup`);
