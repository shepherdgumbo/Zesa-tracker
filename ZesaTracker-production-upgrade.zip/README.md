# ZesaTracker

ZesaTracker is a Zimbabwe-focused web app for electricity information, outage reporting and links to official ZETDC resources.

## Production architecture

- Existing `server.js` remains the application backend and server-rendered frontend.
- PostgreSQL is optional and is used for persistent outage reports when `DATABASE_URL` is configured.
- AI is optional. Without provider credentials, the existing local assistant fallback keeps the app functional.
- PWA assets live in `public/`.
- GitHub Actions runs syntax checks and integration tests.
- Render configuration is included in `render.yaml`.

## Run

Requirements: Node.js 20+.

```bash
npm install
npm run check
npm test
npm start
```

Open `http://localhost:10000` unless `PORT` is set.

## Environment

Copy `.env.example` to `.env` for local configuration. Never commit `.env`.

`DATABASE_URL` is optional. Production should use a managed PostgreSQL/Supabase connection string.

AI credentials must remain server-side. Do not put them in browser JavaScript.

## PWA

The production hardening patch adds:

- `manifest.webmanifest`
- `sw.js`
- lightweight SVG application icon
- service-worker registration injected into the existing server-rendered page

API requests are deliberately not cached.

## Security

The hardening patch adds:

- stricter request body limits
- configurable CORS
- proxy-aware IP handling
- secure headers through Helmet
- same-origin PWA assets
- AI credentials kept server-side
- no fabricated live outage information
- automated checks for the production surface

The existing application also retains its report validation, rate limiting and official ZETDC links.

## Outage data policy

User-submitted reports are reports, not official ZETDC outage confirmations. ZesaTracker must never present an unverified user report as an official live outage.

Official ZETDC information should be checked at the links already embedded in `server.js`.

## PostgreSQL

When `DATABASE_URL` is present, the existing database initialization creates the `reports` table. If it is absent, the app continues using its existing in-memory fallback.

For a production deployment, configure a managed PostgreSQL database and set `DATABASE_URL` as a platform secret.

## Render

`render.yaml` provides:

- Node runtime
- `npm ci` build
- `npm start`
- `/api/health` health check

Set `DATABASE_URL` and `ALLOWED_ORIGINS` in Render's environment settings.

## Important

Do not claim that a particular Zimbabwe area currently has power or is load-shedding unless a verified live source supports that claim. User reports and official utility information must remain clearly separated.
