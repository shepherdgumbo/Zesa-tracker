Static PWA assets used by the production hardening patch. The application remains server-rendered by server.js.
