# Apply the production upgrade

1. Copy these files into the root of `shepherdgumbo/Zesa-tracker`.
2. Keep the existing `server.js`.
3. Run:
   `node scripts_harden.js`
4. Then run:
   `npm install`
   `npm run check`
   `npm test`
5. Commit the changes and deploy.

The hardening script makes a backup named `server.js.pre-production-backup` before changing server.js.

The script is deliberately additive: it preserves the existing server-rendered UI and API and adds the PWA/security integration around them.
