const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");

const root = path.resolve(__dirname, "..");

test("production files exist", () => {
  for (const file of [
    "package.json",
    ".env.example",
    "render.yaml",
    "README.md",
    "public/manifest.webmanifest",
    "public/sw.js",
    "public/icon.svg",
    ".github/workflows/ci.yml"
  ]) {
    assert.equal(fs.existsSync(path.join(root, file)), true, file);
  }
});

test("manifest is valid JSON and has install metadata", () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, "public/manifest.webmanifest"), "utf8"));
  assert.equal(manifest.display, "standalone");
  assert.equal(manifest.start_url, "/");
  assert.ok(Array.isArray(manifest.icons) && manifest.icons.length > 0);
});

test("server.js passes Node syntax validation", () => {
  const { execFileSync } = require("node:child_process");
  execFileSync(process.execPath, ["--check", path.join(root, "server.js")], { stdio: "pipe" });
});

test("health endpoint responds when server starts without optional services", async () => {
  const port = 18181 + Math.floor(Math.random() * 1000);
  const child = spawn(process.execPath, ["server.js"], {
    cwd: root,
    env: { ...process.env, NODE_ENV: "test", PORT: String(port), DATABASE_URL: "" },
    stdio: ["ignore", "pipe", "pipe"]
  });

  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("server start timeout")), 7000);
      child.stdout.on("data", data => {
        if (/listening|server/i.test(data.toString())) {
          clearTimeout(timer);
          resolve();
        }
      });
      child.on("error", reject);
    });

    const response = await fetch(`http://127.0.0.1:${port}/api/health`);
    assert.equal(response.ok, true);
    const body = await response.json();
    assert.equal(body.ok, true);
  } finally {
    child.kill("SIGTERM");
  }
});
